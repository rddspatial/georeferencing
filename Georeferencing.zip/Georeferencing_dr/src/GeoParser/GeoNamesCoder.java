package GeoParser;
import org.geonames.InsufficientStyleException;
import org.geonames.Toponym;
import org.geonames.ToponymSearchCriteria;
import org.geonames.ToponymSearchResult;
import org.geonames.WebService;


public class GeoNamesCoder {

	public GeoNamesCoder()
	{
		
	}
	
	
	public Coordinate getCoordinates(String doc, String userid)
	{
		WebService.setUserName(userid); // add your username here (signup in geonames
		Coordinate coordiante=null;
		String LIW=doc;	  // the location indicative word or place name whose coordinate is to be known	
		ToponymSearchCriteria searchCriteria = new ToponymSearchCriteria();
		searchCriteria.setQ(LIW);
		ToponymSearchResult searchResult = null;
		try {
			searchResult = WebService.search(searchCriteria);
		} catch (Exception e) {
			e.printStackTrace();
		}
		  for (Toponym toponym : searchResult.getToponyms()) 
		  {
		     double lat=toponym.getLatitude();
		     double lon=toponym.getLongitude();
		     System.out.println ("Search term: "+LIW+" retreived toponym: "+toponym.getName()+" "+"lat: "+lat+" :lon: "+lon+" Country:"+ toponym.getCountryName());
		      coordiante=new Coordinate(lat,lon);
		      break;
		  }
		
		return coordiante;  
	}
	
}
