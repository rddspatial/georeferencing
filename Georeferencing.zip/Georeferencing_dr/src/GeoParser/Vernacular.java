package GeoParser;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.TokenizerModel;
import GeoCoderOSMExtended.GetCoordinatesDriver;
import GeoCoderOSMExtended.Place;

public class Vernacular {

	public Vernacular()
	{
		
	}
	
	public ArrayList<String> getToponymsWithoutOSMCheck (String doc) throws IOException
	{
		
		boolean flag1=false;
		boolean flag2=false;
		ArrayList <String> toponymList= new ArrayList <String> ();
		ArrayList <Place> placeList= new ArrayList <Place> ();
		ArrayList <Token> tokenList= new ArrayList <Token> ();
		String s="";
		GeoNamesCoder gd=new GeoNamesCoder();
		GetCoordinatesDriver gcd=new GetCoordinatesDriver ();
		boolean flag=false;
		 String tags[] = null;
	      InputStream inputStreamTokenizer = new 
	         FileInputStream("res\\en-token.bin"); 
	      TokenizerModel tokenModel = new TokenizerModel(inputStreamTokenizer); 
	      
	    //Instantiating the TokenizerME class 
//	      TokenizerME tokenizer = new TokenizerME(tokenModel); 
//	      String tokens[] = tokenizer.tokenize(doc); 
	     
	     
	      String tokens[] =doc.split("[\\p{P} \\t\\n\\r]");
	      tokenList.clear();
	      InputStream modelIn = null;

	      try {
	        modelIn = new FileInputStream("res\\en-pos-maxent.bin");
	        POSModel model = new POSModel(modelIn);
	      
	        POSTaggerME tagger = new POSTaggerME(model);
	        tags = tagger.tag(tokens);
	        
	      }
	      catch (IOException e) {
	        // Model loading failed, handle the error
	        e.printStackTrace();
	      }
	      finally {
	        if (modelIn != null) {
	          try {
	            modelIn.close();
	          }
	          catch (IOException e) {
	          }
	        }
	      }
	      
	//      System.out.println ("Part-of-speech tagger: ");
	      
	      for (int i=0;i<tags.length;i++)
	      {
	//    	  System.out.println (tokens[i]+": "+tags[i]);
	    	  Token tokenElement=new Token (tokens[i],tags[i],i);
	    	  tokenList.add(tokenElement);
	      }
	      
	      ArrayList<String> vernacularlist=new ArrayList<String> ();
	      try
	      {
	    	  
	    	  BufferedReader br=new BufferedReader (new FileReader ("res\\post_vernacular.txt"));
	    	
	    	  String row;
			while ((row=br.readLine())!=null)
	    	  {
	    		String [] str_arr=row.split("\\s+");
				String vernacular=str_arr[0].trim();
	    		  vernacularlist.add(vernacular);
	    	  }
	    	  br.close();
	      }catch (Exception e)
	      {
	    	  e.printStackTrace();
	      }
	      
	      Pattern special = Pattern.compile ("[@#]");
	      Matcher hasSpecial;
	     for (int i=0;i<tokenList.size();i++)
	     {
	    	 s="";
	    	 hasSpecial=special.matcher(tokenList.get(i).getWord());

//	    	 System.out.println ("in tokenlist: "+tokenList.get(i) );
	    	for (int k=0;k<vernacularlist.size();k++) 
	    	{
	   // 		System.out.println ("in vernacularlist: "+vernacularlist.get(k)); 
	    	if (tokenList.get(i).getWord().equalsIgnoreCase(vernacularlist.get(k)))
	    		 
	    	 {
//	    		System.out.println ("MATCH FOUND");
	    		if (i!=0)
	    		{ 
	    		 if (tokenList.get(i-1).getPOS().equals("NNP") || tokenList.get(i-1).getPOS().equals("NN"))
    			 { 
    		//		System.out.println ("s.token: "+tokenList.get(j).getWord());
	    			 
    					 s=tokenList.get(i-1).getWord()+" "+tokenList.get(i).getWord();
    					 flag1=true;
    					 toponymList.add(s);
    					 break;
    			 } 
    		}
	    		
	    	 }
	     
	     
	     
	     }
	     
}
	     return toponymList; 
}
}