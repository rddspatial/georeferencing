package GeoParser;

import java.io.FileInputStream; 
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;  
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import ApacheOpenNLPRetrainer.Location;
import ApacheOpenNLPRetrainer.OpenNLPLocationTrainer;
import opennlp.tools.namefind.NameFinderME; 
import opennlp.tools.namefind.TokenNameFinderModel; 
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.TokenizerME; 
import opennlp.tools.tokenize.TokenizerModel; 
import opennlp.tools.util.Span;  

public class LocationFinderOpenNLP { 
   
	OpenNLPLocationTrainer olf;
	
	public LocationFinderOpenNLP() throws FileNotFoundException
	{
		 olf=new OpenNLPLocationTrainer();
	}
	

	public ArrayList<String> getToponyms (ArrayList<String> doclist)throws Exception{
 
	  ArrayList<String> toponymList=new ArrayList<String> ();
	  for (int k=0;k<doclist.size();k++)
	  {
		  String paragraph = doclist.get(k);  
		  String tags[] = null;
	      InputStream inputStreamTokenizer = new FileInputStream("res\\en-token.bin"); 
	      TokenizerModel tokenModel = new TokenizerModel(inputStreamTokenizer); 
	      
	    //Instantiating the TokenizerME class 
	      TokenizerME tokenizer = new TokenizerME(tokenModel); 
	      String tokens[] = tokenizer.tokenize(paragraph); 
	       
	      InputStream modelIn = null;

     try 
     {
        modelIn = new FileInputStream("res\\en-pos-maxent.bin");
        POSModel model = new POSModel(modelIn);
      
        POSTaggerME tagger = new POSTaggerME(model);
        tags = tagger.tag(tokens);
      }
      catch (IOException e) {
        // Model loading failed, handle the error
        e.printStackTrace();
      }
      finally {
        if (modelIn != null) {
          try {
            modelIn.close();
          }
          catch (IOException e) {
          }
        }
      }
      

      //Loading the NER-location moodel 
      InputStream inputStreamNameFinder = new 
         FileInputStream("res\\en-ner-location.bin");       
      TokenNameFinderModel model = new TokenNameFinderModel(inputStreamNameFinder); 
        
      //Instantiating the NameFinderME class 
      NameFinderME nameFinder = new NameFinderME(model);      
        
      //Finding the names of a location 
      Span nameSpans[] = nameFinder.find(tokens);        
      //Printing the spans of the locations in the sentence 
 
      for(Span s: nameSpans)     
      {

    	  toponymList.add(tokens[s.getStart()]);
      }
   } 
   
   return toponymList;
   }
   

   public ArrayList<String> getToponymsfromRetrainedOpenNLP (ArrayList<String> doclist)throws Exception
   {
	   Set<Location> placeset=new HashSet<Location> ();
	   ArrayList<String> toponymlist=new ArrayList<String> ();
	  
	   String text="";
	   for (int i=0;i<doclist.size();i++)
	   {
		   text=text+" "+doclist.get(i);
	   }
	   
	   placeset=olf.getLocations(text);
	   
	   for (Location l:placeset)
	   {
		   toponymlist.add(l.getLocation());
	   }
	   
	   return toponymlist;
	}
   
   
}   