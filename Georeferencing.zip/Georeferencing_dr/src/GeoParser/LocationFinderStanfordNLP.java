package GeoParser;

import java.io.*;
import java.util.*;

import edu.stanford.nlp.io.IOUtils;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreAnnotations.LemmaAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.NamedEntityTagAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.PartOfSpeechAnnotation;
import edu.stanford.nlp.ling.CoreAnnotations.TextAnnotation;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.*;
import edu.stanford.nlp.trees.Tree;
import edu.stanford.nlp.trees.TreeCoreAnnotations;
import edu.stanford.nlp.trees.TreeCoreAnnotations.TreeAnnotation;
import edu.stanford.nlp.util.CoreMap;

public class LocationFinderStanfordNLP {
	   StanfordCoreNLP pipeline;
	public LocationFinderStanfordNLP()
	{
		  Properties props = new Properties();
		    props.setProperty("annotators", "tokenize, ssplit, pos, lemma, ner, parse, dcoref");
		    pipeline = new StanfordCoreNLP(props);
	}

  public ArrayList<String> getToponyms(ArrayList<String> doclist) throws IOException {
	System.gc();
	ArrayList<String> toponymList=new ArrayList<String> ();
	int docSize=doclist.size();  
	PrintWriter out = null;
	String text=doclist.get(0);
	String [] args = {""};
	PrintWriter xmlOut = null;
	out = new PrintWriter(System.out);
    xmlOut = new PrintWriter("x");
    Annotation [] document=new Annotation[docSize];
    
    if (docSize > 0) {

    	for (int i=0;i<doclist.size();i++)
    	{
    		document[i] = new Annotation(doclist.get(i));
    	}
    }

    for (int i=0;i<docSize;i++)
    {
	    pipeline.annotate(document[i]);
	
	    for (CoreMap sentence: document[i].get(CoreAnnotations.SentencesAnnotation.class)) {
	    	 // get the tree for the sentence
	    	 Tree tree = sentence.get(TreeAnnotation.class);
	    	 // get the tokens for the sentence and iterate over them
	//    	 System.out.println("Executing CoreLabels....");
	    	 for (CoreLabel token: sentence.get(CoreAnnotations.TokensAnnotation.class)) {
	    	 // get token attributes
	    	 String tokenText = token.get(TextAnnotation.class);
	    	 String tokenPOS = token.get(PartOfSpeechAnnotation.class);
	    	 String tokenLemma = token.get(LemmaAnnotation.class);
	    	 String tokenNE = token.get(NamedEntityTagAnnotation.class);
		    	  if (tokenNE.equals("LOCATION"))
		    		{
		    			toponymList.add(tokenText);	 
		    		}
	    		 }
	    	 }
	}
    
	return toponymList;
  
  	}
  }

