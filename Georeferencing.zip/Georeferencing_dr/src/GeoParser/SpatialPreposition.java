package GeoParser;

public class SpatialPreposition {

	String preposition="";
	int index=0;
	
	
	public SpatialPreposition()
	{
		
	}
	
	public SpatialPreposition(String preposition, int index)
	{
		this.preposition=preposition;
		this.index=index;
	}
	
	public String getPreposition()
	{
		return preposition;
	}
	
	public int getIndex()
	{
		return index;
	}
	
	
}
