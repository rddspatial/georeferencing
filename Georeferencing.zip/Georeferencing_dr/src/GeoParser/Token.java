package GeoParser;

public class Token {

	String word="";
	String pos="";
	int index=0;
	
	public Token(String word, String pos,int index)
	{
		this.word=word;
		this.pos=pos;
		this.index=index;
	}
	
	public String getWord()
	{
		return word;
	}
	
	public String getPOS()
	{
		return pos;
	}
	public int getIndex()
	{
		return index;
	}
	
	public String toString()
	{
		return word+": "+pos+" "+index; 
	}
}
