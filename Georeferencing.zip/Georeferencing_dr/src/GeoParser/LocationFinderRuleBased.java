package GeoParser;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import GeoCoderOSMExtended.GetCoordinatesDriver;
import GeoCoderOSMExtended.Place;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

public class LocationFinderRuleBased {

	public LocationFinderRuleBased()
	{
		
	}
	


	public ArrayList<String> getToponymsWithoutOSMCheck (ArrayList<String> doclist) throws IOException
	{
		
	ArrayList <String> toponymList= new ArrayList <String> ();
	for (int di=0;di<doclist.size();di++)
	{
		
		String doc = doclist.get(di);
		boolean flag1=false;
	
		 ArrayList <Token> tokenList= new ArrayList <Token> ();
		 String s="";
		
		 String tags[] = null;
	     InputStream inputStreamTokenizer = new 
	     FileInputStream("res\\en-token.bin"); 
	     TokenizerModel tokenModel = new TokenizerModel(inputStreamTokenizer); 
	     String tokens[] =doc.split("[\\p{P} \\t\\n\\r]");
	     tokenList.clear();
	     InputStream modelIn = null;

	      try {
	        modelIn = new FileInputStream("res\\en-pos-maxent.bin");
	        POSModel model = new POSModel(modelIn);
	      
	        POSTaggerME tagger = new POSTaggerME(model);
	        tags = tagger.tag(tokens);
	        
	      }
	      catch (IOException e) {
	        // Model loading failed, handle the error
	        e.printStackTrace();
	      }
	      finally {
	        if (modelIn != null) {
	          try {
	            modelIn.close();
	          }
	          catch (IOException e) {
	          }
	        }
	      }
	      
//	      System.out.println ("Part-of-speech tagger: ");
	      
	      for (int i=0;i<tags.length;i++)
	      {
//	    	  System.out.println (tokens[i]+": "+tags[i]);
	    	  Token tokenElement=new Token (tokens[i],tags[i],i);
	    	  tokenList.add(tokenElement);
	      }
	      
	      ArrayList<String> vernacularlist=new ArrayList<String> ();
	      try
	      {
	    	  
	    	  BufferedReader br=new BufferedReader (new FileReader ("res\\post_vernacular.txt"));
	    	
	    	  String row;
			while ((row=br.readLine())!=null)
	    	  {
	    		  String vernacular=row.trim();
	    		  vernacularlist.add(vernacular);
	    	  }
	    	  br.close();
	      }catch (Exception e)
	      {
	    	  e.printStackTrace();
	      }
	      
	      Pattern special = Pattern.compile ("[@#]");
	      Matcher hasSpecial;
	     for (int i=0;i<tokenList.size();i++)
	     {
	    	 s="";
	    	 int count2=0;
	    	 hasSpecial=special.matcher(tokenList.get(i).getWord());	 
	    	 if (tokenList.get(i).getWord().equalsIgnoreCase("at") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("from") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("to") || 
	    			 hasSpecial.find()|| 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("on") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("near") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("in") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("behind") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("beside") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("around") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("towards") ||
	    			 tokenList.get(i).getWord().equalsIgnoreCase("toward") ||
	    			 tokenList.get(i).getWord().equalsIgnoreCase("front of") ||
	    			 tokenList.get(i).getWord().equalsIgnoreCase("east") ||
	    			 tokenList.get(i).getWord().equalsIgnoreCase("west") || 
	    			 tokenList.get(i).getWord().equalsIgnoreCase("north") ||
	    			 tokenList.get(i).getWord().equalsIgnoreCase("south")
	    			 ) 
	    		 
	    	 {
	    		 for (int j=i+1;j<tokenList.size();j++)
	    		 {
	
	    			if (count2==2)
	    			{
	    				break;
	    			}
	    			 
	    			if (tokenList.get(j).getPOS().equals("NNP") || tokenList.get(j).getPOS().equals("NN"))
	    			 { 
	    					 s=s+" "+tokenList.get(j).getWord();
	    					 flag1=true;
	    					 count2++;
	    			 }
	    			 else 
	    			 {
	    			
	    				 if (flag1==true)
	    				 {
	    					
	    					 if (s.length()>0)
	    					 {
	    					 
	    						 toponymList.add(s);
	    						 flag1=false;
	    						 
	    					 }
	    				 }
	    				 
	    				 break;
 
	    			 }
	    			
	    			
	    			if (j==tokenList.size()-1 && flag1==true)
	    			{
	    				if (s.length()>0)
	    				{
	    					 
	    						 toponymList.add(s);
	    				}
	    			}
	    			
	    		 }
	    		
	    		 
	    	 }
	     }
	     
	}

	     return toponymList; 
}


	public String reverseString(String source) {
	    int i, len = source.length();
	    StringBuilder dest = new StringBuilder(len);

	    for (i = (len - 1); i >= 0; i--){
	        dest.append(source.charAt(i));
	    }

	    return dest.toString();
	}
}
	