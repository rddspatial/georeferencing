package GeoParser;

public class Coordinate {

	double lat=0;
	double lon=0;
	
	public Coordinate()
	{
		
	}
	
	public Coordinate(double lat, double lon)
	{
		this.lat=lat;
		this.lon=lon;
	}
	
	
	public double getLat()
	{
		return lat;
	}
	
	public double getLon()
	{
		return lon;
	}
	
	
	
}
