package GeographicInformationRetrieval_RD;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import Filter.SymbolRemoverEngine;
import GeoParser.LocationFinderOpenNLP;
import GeoParser.LocationFinderRuleBased;
import GeoParser.LocationFinderStanfordNLP;
import GeoParser.Vernacular;



public class ToponymRetriever {

	LocationFinderOpenNLP lfo=null;
	LocationFinderStanfordNLP lfs=null;
	LocationFinderRuleBased lfr=null;
	public ToponymRetriever () throws FileNotFoundException
	{
		System.out.println ("Loading retrained OpenNLP...");
		lfo=new LocationFinderOpenNLP();
		System.out.println ("Loading StanfordCoreNLP...");
		lfs=new LocationFinderStanfordNLP();
		System.out.println ("Loading Vernacular lexicon...");
		lfr=new LocationFinderRuleBased ();
	}
	
	
	public ArrayList<String> getToponymList (String input) throws Exception {

		Vernacular vern=new Vernacular ();
		
		SymbolRemoverEngine symbolremove=new SymbolRemoverEngine();
		
		Set<String> toponymset=new HashSet<String> ();
		
		ArrayList<String> toponymlist=new ArrayList<String> ();
		ArrayList<String> placenameliststanford=new ArrayList<String> ();
		ArrayList<String> doclist=new ArrayList<String> ();
		ArrayList<String> placenamelist=new ArrayList<String> ();
		ArrayList<String> placenamelistopenNLP=new ArrayList<String> ();
		ArrayList<String> placenamelistpre=new ArrayList<String> ();
		ArrayList<String> placenamelistvernacular=new ArrayList<String> ();

		String cleanedinput=input.replaceAll("[^A-Za-z0-9- ]", " ");
		
	//break a text into a number of sentences using regex operator and them to doclist
		
		 String[] tokens = cleanedinput.split("(?<=[a-z])\\.\\s+");
	      for (String s:tokens)
	      {
	    	  doclist.add(s);
	      }

		placenamelist=lfr.getToponymsWithoutOSMCheck(doclist);
	//	placenamelistpre=lfr.getToponymsWithoutOSMCheckPreSpatialPreposition(cleanedinput);
		placenameliststanford=lfs.getToponyms(doclist);
	//	placenamelistopenNLP=lfo.getToponyms(doclist);  //default
		placenamelistopenNLP=lfo.getToponymsfromRetrainedOpenNLP(doclist); //retrained
		placenamelistvernacular=vern.getToponymsWithoutOSMCheck(cleanedinput);

//		System.out.println ("total placename detected using rule-based technique: "+placenamelist.size());
//		for (int i=0;i<placenamelist.size();i++)
//		{
//			System.out.println ("location "+i+" :"+placenamelist.get(i));
//		}
//
//		System.out.println ("total placename detected using OpenNLP: "+placenamelistopenNLP.size());
//		for (int i=0;i<placenamelistopenNLP.size();i++)
//		{
//			System.out.println ("location "+i+" :"+placenamelistopenNLP.get(i));
//		}
//		
//		System.out.println ("total placename detected using StanfordNLP: "+placenameliststanford.size());
//		for (int i=0;i<placenameliststanford.size();i++)
//		{
//			System.out.println ("location "+i+" :"+placenameliststanford.get(i));
//		}
		
		for (String s:placenamelistopenNLP)
		{
			toponymset.add(s.trim());
		}
		for (String s:placenamelist)
		{
			toponymset.add(s.trim());
		}
		for (String s:placenameliststanford)
		{
			toponymset.add(s.trim());
		}
		for (String s:placenamelistvernacular)
		{
			toponymset.add(s.trim());
		}
		for (String s:toponymset)
		{
			toponymlist.add(s.trim());
		}
		for (String s:placenamelistpre)
		{
			toponymlist.add(s.trim());
		}
		ArrayList <String> checklist=new ArrayList<String>();
		checklist=toponymlist;
		
		for (int i=0;i<toponymlist.size();i++)
		{
			String str_arr[]=toponymlist.get(i).split("\\s+");
			String str1=toponymlist.get(i);
			if (str_arr.length>1)
			{
			for (int j=0;j<checklist.size();j++)
			{
				String str2=checklist.get(j);
				
				if (!str1.equals(str2))
				{
				if (str1.toLowerCase().contains(str2.toLowerCase()))
				{
					checklist.remove(j);
				}
				}
			}
			}
		}
		
		return checklist;
	}


	
}