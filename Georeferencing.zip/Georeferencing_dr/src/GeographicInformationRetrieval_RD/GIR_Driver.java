package GeographicInformationRetrieval_RD;
/*
 * @author Rahul Deb Das (spatialinformatica@gmail.com)
 *
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import Filter.WebLinkRemoverEngine;
import GeoCoderOSMExtended.Place;

public class GIR_Driver {

	public static void main(String[] args) throws Exception {

		String spatial_context="Maharashtra"; //Spatial context is used for toponym disambiguation to narrow down the IR. You can use any other spatial context depending on your study area. If you are not sure about the context, leave it blank ("").
		String text1="";
		String text2="";
		String text="";
		
		text1="traffic in mumbai is getting horrible. we are waiting for uber at Powai.";
		text2="@tweeting now. Truck accident @ #Bapuji Marg. There is a long traffic from CST station to colaba";	
		
		String cleanedtext="";
		int count=0;
		double lat=0;
		double lon=0;
		String place="";
		String state="";
		String country="";
		String placetype="";
		String postcode="";
			
			ToponymRetriever tr=new ToponymRetriever ();
			CoordinateRetriever cr=new CoordinateRetriever ();
			WebLinkRemoverEngine wr=new WebLinkRemoverEngine();
			ArrayList<Place> placelistlist=new ArrayList<Place> ();
			ArrayList<String> toponymlist=new ArrayList<String> ();
			
			ArrayList<String> rplacenamelist=new ArrayList<String> ();
			
			ArrayList<String> textlist=new ArrayList<String> ();
			
			//populate the textlist manually or by reading texts from a csv file, and add the text from each row to the textlist
			textlist.add(text1);
			textlist.add(text2);
			//
			
			//iterating over the textlist
			for (int k=0;k<textlist.size();k++)
			{
				text=textlist.get(k);
				ArrayList<String> placelist_text = new ArrayList<String> (); //arraylist contining all the place mentions in a given text
				Set<String> placenameset = new HashSet<String> ();
				System.out.println ("Text "+k+": "+"Input text: "+text);
				System.out.println ("------------------------------------------------------------------------------");
				cleanedtext=wr.executeWebLinkRemover(text);
				 String[] tokens = cleanedtext.split("(?<=[a-z])\\.\\s+");
			      for (int p=0;p<tokens.length;p++)  //looping over individual sentence in the text
			      {
			    	  String s=tokens[p];
	//		    	  System.out.println ("Text "+k+"_"+p+": "+s); 
	//				  System.out.println ("--------------------------------------------------------------");
					  count=0;
						
					  toponymlist=tr.getToponymList(s);
					  for (String t: toponymlist)
					   {
							placelist_text.add(t);
					   }
			} 
			
//  Printing all the retrieved toponyms from the given text 					
				  for (int j=0;j<placelist_text.size();j++)
					{
						String str = placelist_text.get(j);
						String cap_place = str.substring(0, 1).toUpperCase() + str.substring(1); //capitalizing the first letter of the placename
						System.out.println (j+": "+cap_place);
//  You can write the retrieved toponyms in a file/database at this point						
// writing on file/database ....
// .......						
					}
					placelistlist=cr.getPlaceList(placelist_text);
		
					System.out.println ("Geocoding placenames using OSM...");
					System.out.println ("-----------------------------------------------------");
					for (int i=0;i<placelistlist.size();i++)
					{
						lat=placelistlist.get(i).getLatitude();
						lon=placelistlist.get(i).getLongitude();
						place=placelistlist.get(i).getPlaceName();
						placetype=placelistlist.get(i).getObjectType();
						postcode=placelistlist.get(i).getPostCode();
						state=placelistlist.get(i).getStateName();
						country=placelistlist.get(i).getCountryName();

						if (placelistlist.get(i).getStateName()!=null )
						{	
							if (placelistlist.get(i).getStateName().equalsIgnoreCase(spatial_context) )
							{
								
								boolean flag=isContainedIn(rplacenamelist,placelistlist.get(i).getPlaceName());
								
								if (!flag)
								{
								
									if (!placenameset.contains(place))  //placename redundancy check START
									{
											placenameset.add(place);	
											
											System.out.println(count+","+
												place+","+
												lat+","+
												lon+","+
												placetype+","+
												postcode+","+
												state+","+
												country
												);
										count++;
//instead of printing the toponyms and their coordinates on the screen, you can write this information in a file/database			

// Writing on file/database at this point ......										
										
//Optional: create an object Place with attributes as placename, lat, lon, placetype, postcode, state, country
//and add them in an arraylist. Use that arraylist for other downstream task.
								   } //placename redundancy check END
								
								}
							
							}
					    }
 
					}
					placelist_text.clear();
					placelistlist.clear();
					System.out.println();
				
	}
		
			System.out.println ("------------------------COMPLETE-------------------------");
			
	
	}

	
	public static boolean isContainedIn(ArrayList<String> rplacelist,String query)
	{
		boolean flag=false;
		
		for (int j=0;j<rplacelist.size();j++)
		{
			if (query.equalsIgnoreCase(rplacelist.get(j)))
			{
				flag=true;
			}
		}
		return flag;
	}
	
}
