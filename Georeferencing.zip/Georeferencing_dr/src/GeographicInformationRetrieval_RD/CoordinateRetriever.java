package GeographicInformationRetrieval_RD;

import java.util.ArrayList;

import GeoCoderOSMExtended.GetCoordinatesDriver;
import GeoCoderOSMExtended.Place;

public class CoordinateRetriever {

	public CoordinateRetriever()
	{
		
	}
	
	
	public ArrayList<Place> getPlaceList (ArrayList<String> toponymlist)
	{
		GetCoordinatesDriver gcd=new GetCoordinatesDriver ();
		
		ArrayList<Place> placelist=new ArrayList<Place> ();
		for (int i=0;i<toponymlist.size();i++)
		{
			placelist=gcd.getLocationInfo(toponymlist.get(i));
		}
		
		return placelist;
	}

}
