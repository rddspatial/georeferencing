package ApacheOpenNLPRetrainer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import opennlp.tools.ml.model.AbstractModel;
import opennlp.tools.namefind.BioCodec;
import opennlp.tools.namefind.NameFinderME;
import opennlp.tools.namefind.NameSampleDataStream;
import opennlp.tools.namefind.TokenNameFinder;
import opennlp.tools.namefind.TokenNameFinderFactory;
import opennlp.tools.namefind.TokenNameFinderModel;
import opennlp.tools.tokenize.SimpleTokenizer;
import opennlp.tools.util.InputStreamFactory;
import opennlp.tools.util.MarkableFileInputStreamFactory;
import opennlp.tools.util.ObjectStream;
import opennlp.tools.util.PlainTextByLineStream;
import opennlp.tools.util.Span;
import opennlp.tools.util.TrainingParameters;
import opennlp.tools.util.model.BaseModel;

public class OpenNLPLocationTrainer {

	TokenNameFinderModel nameFinderModel = null;
	
	public OpenNLPLocationTrainer() throws FileNotFoundException
	{
	
		//reading annotated file (NER annotated)
		InputStreamFactory in = null;
		
		
		try {
		    in = new MarkableFileInputStreamFactory(new File("res/OpenNLPTraining_NER_loc.txt"));
		} catch (FileNotFoundException e2) {
		    e2.printStackTrace();
		}
		 
		ObjectStream sampleStream = null;
		try {
		    sampleStream = new NameSampleDataStream(
		        new PlainTextByLineStream(in, StandardCharsets.UTF_8));
		} catch (IOException e1) {
		    e1.printStackTrace();
		}
		
		//training parameters
		TrainingParameters params = new TrainingParameters();
		params.put(TrainingParameters.ITERATIONS_PARAM, 150);
		params.put(TrainingParameters.CUTOFF_PARAM, 3);
		
		//train the model
	
		try {
			nameFinderModel = NameFinderME.train("en", null, sampleStream,
        params, TokenNameFinderFactory.create(null, null, Collections.emptyMap(), new BioCodec()));
			} catch (IOException e) 
			{
				e.printStackTrace();
			}
		
		//save the model
		
		File output = new File("ner-location-custom-model.bin"); //location model(this could be person or organization or any Named entity model)
		FileOutputStream outputStream = new FileOutputStream(output);
		try {
			nameFinderModel.serialize(outputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 
		//testing the model
		
		public Set<Location> getLocations (String text) throws IOException
		{
			Set<Location> locationset=new HashSet <Location>();
		
			TokenNameFinder nameFinder = new NameFinderME(nameFinderModel);
	        
		// String text="Their is a problem of traffic jam near Infinity Mall Malad  w  its a usual problem will RTO or traffic police will look over it";
		 
		 String[] testSentence = SimpleTokenizer.INSTANCE.tokenize(text);
					
		 
		// 	String[] testSentence ={"I","go","from","Girgaon","to","powai","in","Mumbai","But","don't","take","sv road"};
	 
	  //      System.out.println("Finding types in the test sentence..");
	        Span[] names = nameFinder.find(testSentence);
	        for(Span name:names){
	            String locationName="";
	            for(int i=name.getStart();i<name.getEnd();i++){
	            	locationName+=testSentence[i]+" ";
	            }
	       //     System.out.println(name.getType()+" : "+locationName+"\t [probability="+name.getProb()+"]");
	          Location location=new Location (locationName,name.getProb());
	            locationset.add(location);
	        }
	    
	 //displaying features used in MaxEnt model in OpenNLP
	        
//	        BaseModel model = null;
//			AbstractModel maxModel =  model.getArtifact(openNLPmodel+"ner-location-custom-model.bin");
//            Object[] obj = maxModel.getDataStructures();
//
//            if(obj!=null) {
//                Map<String, Integer> pmap = (HashMap<String, Integer>) obj[1];
//                Set<String> keySet = pmap.keySet();
//                for(String key: keySet) {
//                    System.out.println(key +" **** "+ pmap.get(key));
//                }
//            } else {
//                System.out.println("obj is null." );
//            }

	        return locationset;
	}
}