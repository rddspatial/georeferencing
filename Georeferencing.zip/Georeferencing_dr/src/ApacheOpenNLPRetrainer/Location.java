package ApacheOpenNLPRetrainer;

import java.util.ArrayList;

public class Location {

	double probability=0;
	long tweetid=0;
	String location="";
	
	public Location(long tweetid, String location)
	{
		this.tweetid=tweetid;
		this.location=location;
	}
	
	public Location (String location, double probability) //confidence in detecting as location=probability
	{
		this.location=location;
		this.probability=probability;
	}
	
	public double getProbability()
	{
		return probability;
	}
	
	public long getTweetID()
	{
		return tweetid;
	}
	
	public String getLocation()
	{
		return location;
	}
	
	public ArrayList<String> getLocationlist()
	{
		ArrayList<String> loclist=new ArrayList<String> ();
		
		String [] loc_arr=location.split(",");
		for (int i=0;i<loc_arr.length;i++)
		{
			loclist.add(loc_arr[i]);
		}
		return loclist;
	}
	
	
}
