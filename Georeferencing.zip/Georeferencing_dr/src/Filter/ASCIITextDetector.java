package Filter;

public class ASCIITextDetector {

	public ASCIITextDetector()
	{
		
	}
	
	public boolean isASCII (String text)
	{
		boolean flag=false;
		flag=text.matches("\\A\\p{ASCII}*\\z");
	
		return flag;
	}
	
	public String removeNonASCII (String s)
	{
		String clean = s.replaceAll("\\P{Print}", "");
		return clean;
	}
}
