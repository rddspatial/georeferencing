package Filter;

public class WebLinkRemoverEngine {

	public WebLinkRemoverEngine()
	{
		
	}
	
	public String executeWebLinkRemover(String text)
	{
		 
		String cleanedtext="";
		String str="";
		String str_text_arr[]=text.split("\\s+");
		    
		    for (int k=0;k<str_text_arr.length;k++)
		    {
		    
		    	str=str_text_arr[k];
		    	
		    	if (str.contains("http")||(str.contains(".com")) || str.contains(".in") || str.contains("www.") || str.contains(".ac") )
		    	 {
		    	//	System.out.println(str);
		    		str="";
		    		 
		    	 }
		    	 cleanedtext=cleanedtext+str+" ";
		    	 
		    }
		    	 
	//	    System.out.println (text+":   :"+cleanedtext);
		    return cleanedtext;
	}
	
	
	
}
