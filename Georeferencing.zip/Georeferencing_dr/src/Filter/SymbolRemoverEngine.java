package Filter;
/*
 * This code will take a text and removes any non alpha-numeric character (or symbols # @ $ , . - ;..)
 * from the text and return a cleaned text containing only numbers and english letters/characters (upper case or lower case as it was in the original text)
 * This will leave spaces intact. I assume that's what you want. Otherwise, remove the space from the regex.
 * 
 * 
 */
public class SymbolRemoverEngine {

	public static String getSymbolRemoved(String text)
	{
		String cleanedtext="";
		
		cleanedtext=text.replaceAll("[^A-Za-z0-9 ]", "");
		
//		String [] str_arr=text.split("[\\p{Punct}\\s]+");
//		
//		for (int i=0;i<str_arr.length;i++)
//		{
//			str_arr[i]=str_arr[i].replaceAll("[^A-Za-z0-9 ]", "");
//		}
		
		return cleanedtext;
	}
	
}
