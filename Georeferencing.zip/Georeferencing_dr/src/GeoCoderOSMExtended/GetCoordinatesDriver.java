package GeoCoderOSMExtended;

import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.BasicConfigurator;

public class GetCoordinatesDriver {

   public ArrayList<Place> getLocationInfo(String args) {
    	
    	BasicConfigurator.configure(); //to suppress log4j warning
    	
    	String address = args;
    	
        Map<String, Double> coords;
        String country="";
        String postcode="";
        String suburb="";
        String state="";
        String street="";
        String region="";
        String city="";
        String classType="";
        String objectType="";
        double importance=0;
        String name="";
        double lat=0;
        double lon=0;
        ArrayList<Place> placeList=new ArrayList<Place>();
        
        
        OpenStreetMapUtils.getInstance().executeGeoCode(address);
        placeList=OpenStreetMapUtils.getInstance().getPlaceList();
        
        coords = OpenStreetMapUtils.getInstance().getCoordinates(address);
       
//        suburb=OpenStreetMapUtils.getInstance().getSubrub();      
//        city=OpenStreetMapUtils.getInstance().getCity();
//        state=OpenStreetMapUtils.getInstance().getState();
//        region=OpenStreetMapUtils.getInstance().getRegion();
//        postcode=OpenStreetMapUtils.getInstance().getPostCode();
//        street=OpenStreetMapUtils.getInstance().getStreet();
//        country=OpenStreetMapUtils.getInstance().getCountry();
        		
       
 //---------------Activate the following code block if you want to see the output       

//   System.out.println ("total instances with the same name: "+placeList.size());
   
//   for (int i=0;i<placeList.size();i++)
//   {
//       
//     suburb=placeList.get(i).getSuburbName();  
//     name=placeList.get(i).getPlaceName();
//     city=placeList.get(i).getCityName();
//     state=placeList.get(i).getStateName();
//     region=placeList.get(i).getRegionName();
//     postcode=placeList.get(i).getPostCode();
//     street=placeList.get(i).getStreetName();
//     country=placeList.get(i).getCountryName();
//     classType=placeList.get(i).getClassType();
//     objectType=placeList.get(i).getObjectType();
//     importance=placeList.get(i).getImportance();
//     lat=placeList.get(i).getLatitude();
//     lon=placeList.get(i).getLongitude();
//   
//     System.out.println ("Instance: #"+i);
//     System.out.println ("Place name: "+name);
//     System.out.println("latitude :" + coords.get("lat"));
//     System.out.println("longitude:" + coords.get("lon"));
//
//     System.out.println ("postcode: "+postcode);
//     System.out.println ("city: "+city);
//     System.out.println ("state: "+state);
//     System.out.println ("suburb: "+suburb);
//     
//     System.out.println ("classType: "+classType);
//     System.out.println ("objectType: "+objectType);
//     System.out.println ("importance: "+importance);
//     
//     
//     System.out.println ("country: "+country);
//     
//     
//     System.out.println ("---------------------------------------------------------------------------");
//     
//   }
   
   return placeList;
    }
   
   
   public Place getLocationInfoIndividualPlace(String args, String context) {
   	
   	BasicConfigurator.configure(); //to suppress log4j warning
   	
   	String address = args;
   	
       Map<String, Double> coords;
       String country="";
       String postcode="";
       String suburb="";
       String state="";
       String street="";
       String region="";
       String city="";
       String classType="";
       String objectType="";
       double importance=0;
       String name="";
       double lat=0;
       double lon=0;
       ArrayList<Place> placeList=new ArrayList<Place>();
       Place place=null;
       
       OpenStreetMapUtils.getInstance().executeGeoCode(address);
       placeList=OpenStreetMapUtils.getInstance().getPlaceList();
       
       coords = OpenStreetMapUtils.getInstance().getCoordinates(address);
      
//       suburb=OpenStreetMapUtils.getInstance().getSubrub();      
//       city=OpenStreetMapUtils.getInstance().getCity();
//       state=OpenStreetMapUtils.getInstance().getState();
//       region=OpenStreetMapUtils.getInstance().getRegion();
//       postcode=OpenStreetMapUtils.getInstance().getPostCode();
//       street=OpenStreetMapUtils.getInstance().getStreet();
//       country=OpenStreetMapUtils.getInstance().getCountry();
       		
      
//---------------Activate the following code block if you want to see the output       

//  System.out.println ("total instances with the same name: "+placeList.size());
  
//  for (int i=0;i<placeList.size();i++)
//  {
//      
//    suburb=placeList.get(i).getSuburbName();  
//    name=placeList.get(i).getPlaceName();
//    city=placeList.get(i).getCityName();
//    state=placeList.get(i).getStateName();
//    region=placeList.get(i).getRegionName();
//    postcode=placeList.get(i).getPostCode();
//    street=placeList.get(i).getStreetName();
//    country=placeList.get(i).getCountryName();
//    classType=placeList.get(i).getClassType();
//    objectType=placeList.get(i).getObjectType();
//    importance=placeList.get(i).getImportance();
//    lat=placeList.get(i).getLatitude();
//    lon=placeList.get(i).getLongitude();
//  
//    System.out.println ("Instance: #"+i);
//    System.out.println ("Place name: "+name);
//    System.out.println("latitude :" + coords.get("lat"));
//    System.out.println("longitude:" + coords.get("lon"));
//
//    System.out.println ("postcode: "+postcode);
//    System.out.println ("city: "+city);
//    System.out.println ("state: "+state);
//    System.out.println ("suburb: "+suburb);
//    
//    System.out.println ("classType: "+classType);
//    System.out.println ("objectType: "+objectType);
//    System.out.println ("importance: "+importance);
//    
//    
//    System.out.println ("country: "+country);
//    
//    
//    System.out.println ("---------------------------------------------------------------------------");
//    
//  }
  
       for (int i=0;i<placeList.size();i++)
       {
    	   if (placeList.get(i).getStateName().equalsIgnoreCase(context) || 
    			   placeList.get(i).getCityName().equalsIgnoreCase(context) ||
    			   placeList.get(i).getCountryName().equalsIgnoreCase(context) ||
    			   placeList.get(i).getSuburbName().equalsIgnoreCase(context))
    	   place=placeList.get(i);
       }
       
  return place;
   }
}