package GeoCoderOSMExtended;

public class Place {

	
	String placeName="";
	String street="";
	String city="";
	String suburb="";
	String region="";
	String postcode="";
	String state="";
	String country="";
	String classType="";
	String objectType="";
	double importance=0;
	double lat=0;
	double lon=0;
	
	public Place()
	{
		
	}
	
	public Place(String placeName, String street, String city, String suburb, String region, String postcode, String state, String country,  String classType, String objectType, double importance, double lat, double lon)   
	{
		this.placeName=placeName;
		this.street=street;
		this.city=city;
		this.suburb=suburb;
		this.region=region;
		this.postcode=postcode;
		this.state=state;
		this.country=country;
		this.classType=classType;
		this.objectType=objectType;
		this.importance=importance;
		this.lat=lat;
		this.lon=lon;
	}
	
	public String getPlaceName()
	{
		return placeName;
	}
	
	public String getStreetName()
	{
		return street;
	}
	
	public String getPostCode()
	{
		return postcode;
	}
	
	public String getStateName()
	{
		return state;
	}
	
	public String getCountryName()
	{
		return country;
	}
	
	
	public String getRegionName()
	{
		return region;
	}
	
	public String getSuburbName()
	{
		return suburb;
	}
	

	public String getCityName()
	{
		return city;
	}
	
	public double getLatitude()
	{
		return lat;
	}
	
	public double getLongitude()
	{
		return lon;
	}
	
	public String getClassType()
	{
		return classType;
	}
	
	public String getObjectType()
	{
		return objectType;
	}
	
	public double getImportance()
	{
		return importance;
	}
	public void displayPlaceDetails()
	{
		System.out.println (placeName+", ("+lat+","+lon+"), "+city+","+suburb+","+postcode+","+state+","+country);
	}
}
